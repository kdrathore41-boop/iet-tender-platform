# IET Tender Platform Backend

Backend starter scaffold.
