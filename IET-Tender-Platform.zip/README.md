# IET Tender Platform

Initial project scaffold for the IET Tender Platform.

## Structure
- frontend/
- backend/
- docs/

This is the initial upload package. Expand the modules as development continues.
